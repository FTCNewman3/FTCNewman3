package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;


@TeleOp(name="TeleOp", group="LinearOpmode")
public class TeleOpTeamOrange extends OpMode {

    HardwarePushbotT robot   = new HardwarePushbotT();
    ElapsedTime runtime = new ElapsedTime();
    public double power = 0.7;
    public double turbofade = 0;
    public double i;
    public double shooter = 0.6;

    @Override
    public void init() {
        robot.init(hardwareMap);
    }

    @Override
    public void loop() {
        
    power = (0.3 + (gamepad1.left_trigger/2));


    
    if(gamepad2.a) {
        robot.intake.setPower(1);
    }
    if(gamepad2.b) {
        robot.intake.setPower(0);
    }
    if(gamepad2.x) {
        robot.intake.setPower(-1);
    }
//----------------------------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------------------------
    if(gamepad2.dpad_up) {
        robot.shooter.setPower(shooter);
    }else if(gamepad2.dpad_down) {
        robot.shooter.setPower(0);
    }
    
  
    
        robot.arm.setPower(gamepad2.left_trigger - gamepad2.right_trigger);
        robot.left_back.setPower((gamepad1.left_stick_y + gamepad1.right_stick_x - gamepad1.left_stick_x) * (-power));
        robot.left_front.setPower((gamepad1.left_stick_y - gamepad1.right_stick_x - gamepad1.left_stick_x) * (-power));
        robot.right_back.setPower((gamepad1.left_stick_y - gamepad1.right_stick_x + gamepad1.left_stick_x) * (-power));
        robot.right_front.setPower((gamepad1.left_stick_y + gamepad1.right_stick_x  + gamepad1.left_stick_x) * (-power));
    }

}




